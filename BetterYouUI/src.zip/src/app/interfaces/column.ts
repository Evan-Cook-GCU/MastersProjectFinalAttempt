export interface Column {
    field: string;
    header: string;
}

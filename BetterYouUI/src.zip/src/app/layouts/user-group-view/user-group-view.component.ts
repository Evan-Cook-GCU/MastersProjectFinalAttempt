import { Component } from '@angular/core';

@Component({
  selector: 'app-user-group-view',
  standalone: true,
  imports: [],
  templateUrl: './user-group-view.component.html',
  styleUrl: './user-group-view.component.scss'
})
export class UserGroupViewComponent {

}

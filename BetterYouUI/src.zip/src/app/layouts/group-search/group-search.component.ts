import { Component } from '@angular/core';

@Component({
  selector: 'app-group-search',
  standalone: true,
  imports: [],
  templateUrl: './group-search.component.html',
  styleUrl: './group-search.component.scss'
})
export class GroupSearchComponent {

}

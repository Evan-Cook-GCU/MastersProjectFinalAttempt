import { Component } from '@angular/core';

@Component({
  selector: 'app-layout2',
  standalone: true,
  imports: [],
  templateUrl: './layout2.component.html',
  styleUrl: './layout2.component.scss'
})
export class Layout2Component {

}

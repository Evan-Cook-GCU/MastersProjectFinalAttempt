import { Component } from '@angular/core';

@Component({
  selector: 'app-layout3',
  standalone: true,
  imports: [],
  templateUrl: './layout3.component.html',
  styleUrl: './layout3.component.scss'
})
export class Layout3Component {

}

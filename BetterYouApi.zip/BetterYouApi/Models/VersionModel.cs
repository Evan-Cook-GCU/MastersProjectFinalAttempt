﻿namespace BetterYouApi.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class VersionModel
    {
        /// <summary>
        /// 
        /// </summary>
        public string AssemblyName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string AssemblyVersion { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ServerEnvironment { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ApplicationUpSince { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string BuildTimestamp { get; set; }
    }
}